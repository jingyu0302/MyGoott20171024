
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.time.LocalDateTime;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.mysql.jdbc.Blob;
import com.mysql.jdbc.Connection;

@WebServlet("/BookAdd")
@MultipartConfig(maxFileSize = 16177216)
public class BookAddEng extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String strIsbn;
		String strTitle;
		String strPublisher;
		String strPrice;
		String strPublish;
		String strName;

		String strDBAddMessage = "��� ����";

		DecimalFormat df = new DecimalFormat("###.##");
		Part partImage = request.getPart("image");
		InputStream is = partImage.getInputStream();
		Connection conn = null;

		strIsbn = request.getParameter("isbn");
		strTitle = request.getParameter("title");
		strPublisher = request.getParameter("publisher");
		strName = request.getParameter("name");
		strPrice = request.getParameter("price");
		strPublish = request.getParameter("publish_date");

		LocalDateTime dt = LocalDateTime.now();
		Timestamp t = Timestamp.valueOf(dt);

		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch (Exception ex) {
			System.out.println("mysql jdbc ����̹� �ε� ����");
		}

		try {
			conn = (Connection) DriverManager
					.getConnection("jdbc:mysql://localhost:3306/book_store?" + "user=root&password=admin");

		} catch (SQLException ex) {
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		}

		try {
			String strInsert = "INSERT INTO bookeng(isbn, title, name, image, price, publisher, publish_date, registered_date) VALUES(?,?,?,?,?,?,?,?)";
			PreparedStatement ps = conn.prepareStatement(strInsert);
			ps.setString(1, strIsbn);
			ps.setString(2, strTitle);
			ps.setString(3, strName);
			ps.setBlob(4, is);
			ps.setString(5, strPrice);
			ps.setString(6, strPublisher);
			ps.setString(7, strPublish);
			ps.setTimestamp(8, t);

			int nInsertedCount = ps.executeUpdate();
			if (nInsertedCount == 1) {
				strDBAddMessage = "���� ���";
			}
		} catch (SQLException ex) {
			System.out.println("SQLException: " + ex.getMessage());
			String strImageName = partImage.getName();
		}	
		response.setContentType("text/html;charset=UTF-8");

		PrintWriter out=response.getWriter();
		out.println("<script>alert('��ϵǾ����ϴ�.!!!!!');</script>");
		out.flush();
		out.close();

	}
}

